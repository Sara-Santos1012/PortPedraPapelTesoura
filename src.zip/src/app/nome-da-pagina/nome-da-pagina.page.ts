import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nome-da-pagina',
  templateUrl: './nome-da-pagina.page.html',
  styleUrls: ['./nome-da-pagina.page.scss'],
  standalone: false
})
export class NomeDaPaginaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
